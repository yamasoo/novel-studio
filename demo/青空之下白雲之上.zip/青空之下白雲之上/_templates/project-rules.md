# 小說專案結構與資料庫規範

這份規範是整套 novel-* skill 的共同地基。novel-setup 建專案時照它建資料夾，其他 skill 讀寫檔案時也照它找路徑。

## 一、資料夾結構

```
{書名}/
├── CLAUDE.md                  ← 本書總規則（每次開對話自動載入）
├── bible/                     ← 靜態設定：不常變、寫前查閱
│   ├── story-core.md          題材、賣點、一句話鉤子、故事引擎、讀者契約、終局方向
│   ├── style.md               本書文風：敘事視角、句子節奏、禁忌、範例段落
│   ├── author-prefs.md        作者明確說過「以後都這樣」的習慣
│   ├── glossary.md            專有名詞、稱謂、統一用字
│   ├── world/{主題}.md        一個主題一檔：地理、歷史、力量體系、社會結構……
│   ├── characters/{角色名}.md  一人一檔：靜態人設
│   ├── factions/{勢力名}.md   一個組織一檔
│   └── drafts/                尚未確認的設定（AI 生成、對話萃取），確認後才移進正式資料夾
├── outline/                   ← 計畫：還沒發生的事
│   ├── book.md
│   ├── volumes/vol-01.md      一卷一檔：卷契約與劇情單元
│   └── chapters/ch-0001.md    一章一檔
├── manuscript/
│   └── ch-0001.md
├── tracking/                  ← 已發生的事實：寫完一章才更新
│   ├── state-card.md          目前局勢，每章寫前必讀
│   ├── characters/{角色名}.md  動態快照：位置、傷勢、持有物、知道什麼
│   ├── foreshadowing.md       伏筆總表
│   ├── timeline.md            作者真相與讀者已知
│   ├── reader-knowledge.md    讀者的已知、懸念、誤認（選用；回寫時自動建立）
│   ├── relations.md           角色之間誰對誰的關係與態度，含歷史（選用；回寫時自動建立）
│   └── summaries/ch-0001.md   每章一份短摘要
├── candidates/                候選稿：寫好但作者還沒採用的章節（使用審稿介面時）
├── samples/                   作者滿意的段落，當文風正例（選用）
└── _templates/                各類檔案的空白範本（novel-setup 複製進來）
```

章節檔名是 ch-0001.md（章號補零到四位數），章名寫在正文第一行的標題（`# 第1章 章名`），不放在檔名。角色、勢力、地點等設定檔用繁體中文名字當檔名（bible/characters/林晚.md）。

## 二、三條鐵律

1. **計畫與事實分開。** 大綱和章綱寫「打算發生的事」；追蹤寫「正文裡已經發生的事」。正文寫完前，追蹤不能先改；大綱的計畫也不能當成既成事實引用。
2. **設定與狀態分開。** `bible/characters/` 放不太會變的人設（性格、外貌、背景、說話方式）；`tracking/characters/` 放每章都可能變的東西（在哪、受了什麼傷、帶著什麼、知道哪些秘密、和誰關係如何）。
3. **草稿與正式分開。** AI 生成或從對話整理出來、作者還沒點頭的設定，一律先放 `bible/drafts/`。作者確認後才移進正式資料夾。正文只能引用正式設定。

## 三、YAML frontmatter 規格

每個資料庫檔案開頭都有 YAML 區塊，方便搜尋與檢查。欄位缺值時寫 `null` 或空清單，不要刪欄位。

### 角色（bible/characters/{角色名}.md）

```yaml
---
type: character
name: 林晚
aliases: [晚晚, 林家二小姐]
role: protagonist          # protagonist / main-supporting / supporting / antagonist / minor
first_appearance: 1
status: canon          # canon / draft
---
```

### 勢力、世界觀

```yaml
---
type: faction          # 或 world
name: 天機閣
status: canon
related_characters: [林晚, 沈既白]
---
```

### 章綱（outline/chapters/ch-0001.md）

```yaml
---
type: chapter-card
chapter: 1
title: 退婚當天
volume: 1
target_length: 3000      # 可留空
status: approved        # draft / approved / written
---
```

### 角色狀態（tracking/characters/{角色名}.md）

```yaml
---
type: character-state
name: 林晚
updated_through: 12
last_appearance: 12
---
```

### 章節摘要（tracking/summaries/ch-0001.md）

```yaml
---
type: chapter-summary
chapter: 1
title: 退婚當天
length: 3150
---
```

## 四、追蹤檔的寫法

### tracking/state-card.md（固定七欄，全檔控制在 3000 字內）

1. **目前位置**：第幾卷、第幾章寫完、故事內時間、主要場景
2. **主線進度**：主線走到哪一步，下一個目標是什麼
3. **在場角色**：目前處於故事中心的角色，各一句話近況
4. **下一章承諾**：上一章結尾留給讀者、下一章必須接住的東西
5. **長期約束**：全書都要遵守的規則（例：主角在第三卷前不能暴露身分）
6. **連續性風險**：容易寫錯的細節（例：沈既白左手受傷未癒）
7. **活躍伏筆**：目前該推進或回收的伏筆編號與一句說明

狀態卡是「現在」的快照，不是歷史紀錄。過時的內容直接刪掉，歷史留在章節摘要。

### tracking/foreshadowing.md（一張表）

| 編號 | 內容 | 埋設章 | 預計回收 | 最後出現 | 狀態 | 重要度 |
|---|---|---|---|---|---|---|
| F001 | 母親留下的半塊玉珮 | 第001章 | 第一卷末 | 第008章 | 推進中 | 高 |

狀態只能是：已埋、推進中、已回收、廢棄。重要度：高、中、低。「預計回收」只寫打算回收的那一章（第NNN章），沒定就留空；「第N章起推進」「第N章呼應」這類安排寫在內容或大綱，不然工作台會把它當成回收章來判斷逾期（工作台已會略過這些寫法，但只寫章號最準）。

### tracking/timeline.md（作者真相與讀者已知分欄）

| 編號 | 故事時間 | 實際發生（作者真相） | 讀者目前知道 | 揭示章 | 相關角色 |
|---|---|---|---|---|---|
| E001 | 三年前冬天 | 林父是被沈家設計陷害 | 只知道林父入獄 | 未揭示 | 林父、沈老爺 |

「讀者目前知道」是寫作時的資訊邊界：正文不能讓角色或敘述者說出讀者還不該知道的事。

### tracking/reader-knowledge.md（讀者腦中的狀態，選用）

| 編號 | 類型 | 內容 | 作者真相 | 種下章 | 回收章 | 相關角色 |
|---|---|---|---|---|---|---|
| R001 | 懸念 | 林父為什麼會認罪？ | 沈家拿林母的性命要脅 | 第003章 |  | 林父、沈老爺 |
| R002 | 誤認 | 讀者以為送信的是沈二少 | 其實是沈家老僕 | 第005章 | 第012章 | 沈二少 |

類型只能是：已知（讀者知道、但劇中某些角色還不知道）、懸念（讀者在等答案的問題）、誤認（讀者誤以為的事）。「回收章」空白＝還沒揭曉；「作者真相」選填。時間線記事件，這張表記讀者的疑問與誤會。

### tracking/relations.md（角色之間，誰對誰，選用）

| 編號 | 誰 | 對誰 | 關係 | 態度 | 起始章 | 結束章 | 變化原因 |
|---|---|---|---|---|---|---|---|
| L001 | 沈二少 | 林遠 | 同窗 | 輕視 | 第003章 | 第020章 | 初次見面 |
| L002 | 沈二少 | 林遠 | 盟友 | 敬重 | 第020章 |  | 林遠替他擋下家法 |
| L003 | 林遠 | 沈二少 | 同窗 | 戒備 | 第003章 |  | 初次見面 |

一個方向一列：A 對 B、B 對 A 分開記，兩邊的看法可以不一樣。關係改變時，舊的那列「結束章」填改變的那一章、另開一列，不覆蓋，歷史都留著；「結束章」空白＝目前有效。寫稿時只看在場角色之間目前有效的列，審查時連歷史一起看，抓「沒有原因就變了」或「倒退回去」。

### tracking/summaries/ch-NNNN.md（200～400 字）

寫四件事：這章發生了什麼、局面怎麼變了、新出現的人事物、結尾停在哪裡。

## 五、檔案由誰負責

| 檔案 | 主要寫入者 | 何時寫 |
|---|---|---|
| bible/story-core.md、style.md | novel-setup、novel-outline | 開書、調整方向時 |
| bible/author-prefs.md | 任一 skill | 作者明確說「以後都……」時 |
| bible/characters、factions、world、glossary.md、drafts | novel-bible | 建設定、寫完章節登記新增物時 |
| outline/* | novel-outline | 規劃時 |
| manuscript/* | novel-write | 寫章節時 |
| tracking/* | novel-write（寫完回寫）、novel-review（修正錯誤） | 正文完成後 |

追蹤檔只在正文定稿後更新。作者修改已寫章節時，用 novel-write 的改稿流程，把追蹤一起修正。
