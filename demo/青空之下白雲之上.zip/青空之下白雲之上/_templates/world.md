---
type: world
category:            # 固定清單，選一個：power-system / geography-climate / history / society-politics / economy / religion / culture / technology / vehicles-weapons / ecology / other
tags: []         # 選填，可多個，例如 [艦船, 外星]；category 只能用上面的固定 ID
name:          # 例：力量體系、地理、歷史、社會結構、經濟、宗教
status: draft
---

# {主題}

## 一句話
<!-- 這個設定在故事裡的作用 -->

## 規則
<!-- 寫成可以檢查的規則，不寫成散文。例：
- 修為分九境，每境分前中後三期
- 越境戰鬥幾乎不可能，除非借助外物，且必有代價 -->

## 代價與限制
<!-- 能力越強，限制要越清楚。沒有代價的設定會讓衝突失效 -->

## 讀者何時知道
<!-- 哪些規則開篇就講，哪些留到後面揭露 -->

## 與劇情的關係
<!-- 這個設定會在哪些劇情點被用到 -->

## 備註
